-- NBA Performance Analysis: SQL queries
-- Run all of them with:  python run_queries.py
-- Each query starts with a "-- name:" line so run_queries.py can label the output.


-- name: Regular season vs. playoff efficiency (minutes-weighted TS%)
-- Which players get more efficient when the stakes go up?
SELECT a.Player,
       ROUND(SUM(CASE WHEN a.Type = 'Regular'  THEN a.TS_pct * a.MP END)
           / SUM(CASE WHEN a.Type = 'Regular'  THEN a.MP END), 3) AS regular_ts,
       ROUND(SUM(CASE WHEN a.Type = 'Playoffs' THEN a.TS_pct * a.MP END)
           / SUM(CASE WHEN a.Type = 'Playoffs' THEN a.MP END), 3) AS playoff_ts,
       ROUND(SUM(CASE WHEN a.Type = 'Playoffs' THEN a.TS_pct * a.MP END)
           / SUM(CASE WHEN a.Type = 'Playoffs' THEN a.MP END)
           - SUM(CASE WHEN a.Type = 'Regular'  THEN a.TS_pct * a.MP END)
           / SUM(CASE WHEN a.Type = 'Regular'  THEN a.MP END), 3) AS playoff_change
FROM advanced a
JOIN focus_players f ON f.Player = a.Player
GROUP BY a.Player
ORDER BY playoff_change DESC;


-- name: League trends by decade (pace of the 3-point era)
SELECT (Season_Start / 10) * 10 AS decade,
       COUNT(DISTINCT Player)                           AS players,
       ROUND(SUM(FG3A * G) / SUM(FGA * G), 3)           AS three_point_attempt_rate,
       ROUND(SUM(PTS * G) / SUM(G), 2)                  AS avg_pts_per_player_game
FROM box_scores
WHERE Type = 'Regular'
GROUP BY decade
ORDER BY decade;


-- name: League-wide true shooting % by decade
SELECT (Season_Start / 10) * 10 AS decade,
       ROUND(SUM(TS_pct * MP) / SUM(MP), 3) AS league_ts
FROM advanced
WHERE Type = 'Regular' AND MP > 0
GROUP BY decade
ORDER BY decade;


-- name: Each player's peak season by BPM (window function)
SELECT Player, Season, Age, BPM, PER, WS
FROM (
    SELECT a.Player, a.Season, a.Age, a.BPM, a.PER, a.WS,
           ROW_NUMBER() OVER (PARTITION BY a.Player ORDER BY a.BPM DESC) AS rn
    FROM advanced a
    JOIN focus_players f ON f.Player = a.Player
    WHERE a.Type = 'Regular'
)
WHERE rn = 1
ORDER BY BPM DESC;


-- name: Career aging curve (average regular-season BPM by age)
SELECT CAST(a.Age AS INTEGER)  AS age,
       COUNT(*)                AS player_seasons,
       ROUND(AVG(a.BPM), 2)    AS avg_bpm
FROM advanced a
JOIN focus_players f ON f.Player = a.Player
WHERE a.Type = 'Regular'
GROUP BY age
ORDER BY age;


-- name: Award resumes (MVP, DPOY, Finals MVP, All-NBA, All-Defensive)
SELECT aw.Player,
       SUM(aw.MVP = 'Winner')               AS mvp,
       SUM(aw.DPOY = 'Winner')              AS dpoy,
       SUM(aw.Finals_MVP = 'Winner')        AS finals_mvp,
       SUM(aw.All_NBA = '1st Team')         AS all_nba_1st,
       SUM(aw.All_NBA <> 'No')              AS all_nba_total,
       SUM(aw.All_Defensive <> 'No')        AS all_defensive
FROM awards aw
JOIN focus_players f ON f.Player = aw.Player
GROUP BY aw.Player
ORDER BY mvp DESC, finals_mvp DESC, all_nba_total DESC;


-- name: Most efficient high-volume scoring seasons (25+ PPG, joined per-game + advanced)
SELECT Player, Season, PTS, TS_pct, USG_pct, BPM
FROM player_seasons
WHERE Type = 'Regular' AND PTS >= 25 AND G >= 50
ORDER BY TS_pct DESC
LIMIT 15;


-- name: Biggest Finals upsets (winner was the betting underdog)
SELECT Year,
       Winning_Team,
       CASE WHEN Winning_Team = Home_Court_Team THEN Away_Court_Team ELSE Home_Court_Team END AS beat,
       CASE WHEN Winning_Team = Home_Court_Team THEN Home_Court_Team_Odds ELSE Away_Court_Team_Odds END AS winner_odds
FROM finals_odds
WHERE (CASE WHEN Winning_Team = Home_Court_Team THEN Home_Court_Team_Odds ELSE Away_Court_Team_Odds END) > 0
ORDER BY winner_odds DESC;
