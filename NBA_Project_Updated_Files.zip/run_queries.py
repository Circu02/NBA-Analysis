"""Run every query in queries.sql against nba.db and print the results.

Usage:
    python run_queries.py             # uses nba.db and queries.sql
    python run_queries.py --csv out   # also save each result as a CSV in ./out
"""

import argparse
import re
import sqlite3
from pathlib import Path

import pandas as pd


def parse_queries(sql_text: str):
    """Split queries.sql into (name, sql) pairs using the '-- name:' markers."""
    blocks = re.split(r"^-- name:\s*", sql_text, flags=re.M)[1:]
    for block in blocks:
        name, _, body = block.partition("\n")
        body = body.strip().rstrip(";")
        if body:
            yield name.strip(), body


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="nba.db")
    parser.add_argument("--sql", default="queries.sql")
    parser.add_argument("--csv", help="folder to save each result as CSV")
    args = parser.parse_args()

    conn = sqlite3.connect(args.db)
    pd.set_option("display.width", 140)
    out_dir = Path(args.csv) if args.csv else None
    if out_dir:
        out_dir.mkdir(exist_ok=True)

    for i, (name, query) in enumerate(parse_queries(Path(args.sql).read_text()), start=1):
        print(f"\n=== {i}. {name}")
        try:
            df = pd.read_sql_query(query, conn)
        except Exception as e:  # e.g. a table that wasn't built because its CSV was missing
            print(f"  skipped: {e}")
            continue
        print(df.to_string(index=False))
        if out_dir:
            df.to_csv(out_dir / f"query_{i:02d}.csv", index=False)
    conn.close()


if __name__ == "__main__":
    main()
