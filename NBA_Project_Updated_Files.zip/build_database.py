"""
Build a SQLite database (nba.db) from the CSV files produced by the
NBA Performance Analysis notebook.

Usage:
    python build_database.py                  # CSVs in the current folder
    python build_database.py --data-dir data  # CSVs in another folder

Then run the analysis queries:
    python run_queries.py
"""

import argparse
import re
import sqlite3
from pathlib import Path

import pandas as pd

# table name -> CSV file written by the notebook
TABLES = {
    "box_scores": "clean_downloaded_box_scores.csv",       # per-game box scores, 1985-2025
    "advanced": "clean_adv_box_scores.csv",                # advanced stats (PER, TS%, BPM, WS...)
    "awards": "NBA_Awards_1985_2025.csv",                  # MVP, DPOY, Finals MVP, All-NBA...
    "career_highs": "NBA_Career_Highs_1985_2025.csv",      # single-game career highs (NBA API)
    "finals_odds": "nba_finals_series_odds_1985_2025.csv", # pre-series Finals betting odds
}

# helpful indexes for the joins and filters used in queries.sql
INDEXES = {
    "box_scores": ["Player", "Season", "Type"],
    "advanced": ["Player", "Season", "Type"],
    "awards": ["Player", "Season"],
}


def clean_column(name: str) -> str:
    """Turn basketball-reference headers into SQL-friendly names.
    e.g. 'TS%' -> 'TS_pct', 'WS/48' -> 'WS_per_48', '3PA' -> 'FG3A', 'Finals MVP' -> 'Finals_MVP'"""
    name = str(name).strip()
    name = re.sub(r"^3P", "FG3", name)
    name = re.sub(r"^2P", "FG2", name)
    name = name.replace("%", "_pct").replace("/", "_per_")
    name = re.sub(r"[^0-9a-zA-Z_]", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")
    if name and name[0].isdigit():
        name = "c_" + name
    return name


def load_table(conn: sqlite3.Connection, table: str, csv_path: Path) -> int:
    df = pd.read_csv(csv_path, encoding="utf-8", encoding_errors="replace", low_memory=False)
    df.columns = [clean_column(c) for c in df.columns]
    df = df.loc[:, ~df.columns.duplicated()]

    # numeric season start year (e.g. '1995-1996' -> 1995) makes era/decade queries easy
    if "Season" in df.columns:
        df["Season_Start"] = pd.to_numeric(df["Season"].astype(str).str[:4], errors="coerce").astype("Int64")

    df.to_sql(table, conn, if_exists="replace", index=False)
    for col in INDEXES.get(table, []):
        if col in df.columns:
            conn.execute(f'CREATE INDEX IF NOT EXISTS idx_{table}_{col} ON {table} ("{col}")')
    return len(df)


def create_views(conn: sqlite3.Connection, loaded: set) -> None:
    # the 10 players the project focuses on
    conn.execute("DROP TABLE IF EXISTS focus_players")
    conn.execute("CREATE TABLE focus_players (Player TEXT PRIMARY KEY)")
    conn.executemany(
        "INSERT INTO focus_players VALUES (?)",
        [(p,) for p in [
            "Michael Jordan", "LeBron James", "Tim Duncan", "Kobe Bryant", "Shaquille O'Neal",
            "Hakeem Olajuwon", "Stephen Curry", "Kevin Durant", "Nikola Jokic", "Giannis Antetokounmpo",
        ]],
    )

    # one row per player-season-type with both per-game and advanced stats
    if {"box_scores", "advanced"} <= loaded:
        conn.execute("DROP VIEW IF EXISTS player_seasons")
        conn.execute("""
            CREATE VIEW player_seasons AS
            SELECT b.Player, b.Season, b.Season_Start, b.Type, b.Age, b.Team, b.Pos,
                   b.G, b.MP AS MPG, b.PTS, b.TRB, b.AST, b.STL, b.BLK,
                   a.MP AS Total_MP, a.PER, a.TS_pct, a.USG_pct, a.WS, a.BPM, a.VORP
            FROM box_scores b
            JOIN advanced a
              ON a.Player = b.Player AND a.Season = b.Season AND a.Type = b.Type
        """)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build nba.db from the project CSVs")
    parser.add_argument("--data-dir", default=".", help="folder containing the CSV files")
    parser.add_argument("--db", default="nba.db", help="output database file")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    conn = sqlite3.connect(args.db)
    loaded = set()
    for table, filename in TABLES.items():
        path = data_dir / filename
        if not path.exists():
            print(f"  skipped {table:<13} ({filename} not found - run the notebook first)")
            continue
        rows = load_table(conn, table, path)
        loaded.add(table)
        print(f"  loaded  {table:<13} {rows:>7,} rows")

    create_views(conn, loaded)
    conn.commit()
    conn.close()
    print(f"\nDatabase written to {args.db}")


if __name__ == "__main__":
    main()
