# NBA Performance Analysis: Comparing 10 All-Time Greats (1985–2025)

A data analysis project that builds a 56,000+ record NBA dataset and uses Python and SQL to compare 10 all-time great players: Michael Jordan, LeBron James, Tim Duncan, Kobe Bryant, Shaquille O'Neal, Hakeem Olajuwon, Stephen Curry, Kevin Durant, Nikola Jokic, and Giannis Antetokounmpo.

## Questions explored
- **Playoff efficiency:** Which players' true shooting % (TS%) rises or falls from the regular season to the playoffs?
- **Finals difficulty:** How hard were each player's Finals, based on pre-series betting odds?
- **Aging curves:** How did each player's impact (BPM) change with age? K-Means clustering splits careers into early, prime, and late phases.
- **Award accuracy:** Did MVP, DPOY, and Finals MVP voting reward the statistically best player?
- **Positional dominance:** How far above other players at their position, in the same season, was each player? (z-scores)

## Data
| Dataset | Source | Method |
|---|---|---|
| Per-game box scores, 1985–2025 (regular season + playoffs) | Basketball-Reference | Downloaded tables |
| Advanced stats (PER, TS%, BPM, WS, VORP) | Basketball-Reference | Downloaded tables |
| Awards and All-NBA/All-Defensive teams | Basketball-Reference | Web scraping (BeautifulSoup) |
| Single-game career highs | NBA API (`nba_api`) | API |
| Finals betting odds | Covers.com | Web scraping |

## Tools
Python (pandas, NumPy, scikit-learn, Matplotlib, BeautifulSoup, requests), SQL (SQLite), Jupyter

## SQL database
`build_database.py` loads the cleaned CSVs into a SQLite database (`nba.db`) with five tables (`box_scores`, `advanced`, `awards`, `career_highs`, `finals_odds`), a `focus_players` table, and a `player_seasons` view that joins per-game and advanced stats.

`queries.sql` contains the SQL analysis:
1. Regular-season vs. playoff TS% (minutes-weighted, conditional aggregation)
2. League 3-point attempt rate and scoring by decade
3. League-wide TS% by decade
4. Each player's peak season by BPM (`ROW_NUMBER()` window function)
5. Career aging curve: average BPM by age
6. Award totals by player (MVP, DPOY, Finals MVP, All-NBA, All-Defensive)
7. Most efficient 25+ PPG seasons (join of per-game and advanced stats)
8. Biggest Finals upsets by betting odds

## How to run
```bash
pip install pandas numpy scikit-learn matplotlib beautifulsoup4 requests ftfy nba_api
# 1. Run the notebook's data collection cells to create the CSV files
# 2. Build the database and run the SQL analysis
python build_database.py
python run_queries.py            # add --csv results to save each query's output
```
The notebook's **SQL Analysis** section runs the same two steps and displays the results inline.
